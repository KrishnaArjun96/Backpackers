CREATE VIEW flight_list AS
  SELECT DISTINCT
    `A`.`Id`                                AS `Id`,
    concat(`L`.`AirlineID`, `L`.`FlightNo`) AS `Flight`
  FROM `backpackers`.`Airport` `A`
    JOIN `backpackers`.`Leg` `L`
  WHERE ((`A`.`Id` = `L`.`ArrAirportID`) OR (`A`.`Id` = `L`.`DepAirportID`));
