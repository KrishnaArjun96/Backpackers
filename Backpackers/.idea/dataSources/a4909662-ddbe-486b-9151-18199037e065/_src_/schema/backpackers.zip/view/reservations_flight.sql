CREATE VIEW reservations_flight AS
  SELECT
    concat(`f`.`AirlineId`, ' ', `f`.`FlightNo`)                              AS `Flight`,
    `r`.`ResrNo`                                                              AS `Reservation`,
    `b`.`Id`                                                                  AS `Booking`,
    `r`.`BookingDate`                                                         AS `BookingDate`,
    `b`.`TravelDate`                                                          AS `TravelDate`,
    (SELECT concat(`p`.`FirstName`, ' ', `p`.`LastName`)
     FROM `backpackers`.`person` `p`
       JOIN `backpackers`.`employee` `e`
     WHERE ((`p`.`Id` = `e`.`PersonId`) AND (`e`.`SSN` = `r`.`EmployeeSSN`))) AS `Representative`
  FROM `backpackers`.`reservation` `r`
    JOIN `backpackers`.`flight` `f`
    JOIN `backpackers`.`booking` `b`
  WHERE ((`f`.`AirlineId` = `b`.`AirlineId`) AND (`f`.`FlightNo` = `b`.`FlightNo`) AND (`b`.`ResrNo` = `r`.`ResrNo`))
  ORDER BY `Reservation`, `Booking`;
