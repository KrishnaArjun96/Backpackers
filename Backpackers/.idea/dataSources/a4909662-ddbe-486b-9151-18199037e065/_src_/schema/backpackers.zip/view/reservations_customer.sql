CREATE VIEW reservations_customer AS
  SELECT DISTINCT
    (SELECT concat(`p`.`FirstName`, ' ', `p`.`LastName`)
     FROM `backpackers`.`person` `p`
       JOIN `backpackers`.`customer` `c`
     WHERE ((`p`.`Id` = `c`.`PersonId`) AND (`r`.`UserId` = `c`.`UserId`) AND
            (`c`.`PersonId` = `r`.`CustomerId`)))                             AS `Customer`,
    concat(`f`.`AirlineId`, ' ', `f`.`FlightNo`)                              AS `Flight`,
    `r`.`ResrNo`                                                              AS `Reservation#`,
    `r`.`BookingDate`                                                         AS `Booking Date`,
    (SELECT concat(`p`.`FirstName`, ' ', `p`.`LastName`)
     FROM `backpackers`.`person` `p`
       JOIN `backpackers`.`employee` `e`
     WHERE ((`p`.`Id` = `e`.`PersonId`) AND (`e`.`SSN` = `r`.`EmployeeSSN`))) AS `Representative`
  FROM `backpackers`.`flight` `f`
    JOIN `backpackers`.`booking` `i`
    JOIN `backpackers`.`reservation` `r`
    JOIN `backpackers`.`person` `p`
    JOIN `backpackers`.`customer` `c`
  WHERE (
    (`r`.`CustomerId` = `c`.`PersonId`) AND (`r`.`UserId` = `c`.`UserId`) AND (`i`.`AirlineId` = `f`.`AirlineId`) AND
    (`i`.`FlightNo` = `f`.`FlightNo`) AND (`i`.`ResrNo` = `r`.`ResrNo`))
  ORDER BY `r`.`ResrNo`;
