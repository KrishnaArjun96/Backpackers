CREATE VIEW sales_report AS
  SELECT
    `backpackers`.`reservation`.`ResrNo`                                                                           AS `Reservation #`,
    concat(month(`backpackers`.`reservation`.`BookingDate`), ' ', year(
        `backpackers`.`reservation`.`BookingDate`))                                                                AS `Date`,
    (`backpackers`.`reservation`.`BookingFee` +
     `backpackers`.`reservation`.`Fare`)                                                                           AS `Sale`,
    (SELECT concat(`p`.`FirstName`, ' ', `p`.`LastName`)
     FROM `backpackers`.`person` `p`
       JOIN `backpackers`.`employee` `e`
     WHERE (`p`.`Id` =
            `e`.`PersonId`))                                                                                       AS `Representative`
  FROM `backpackers`.`reservation`;
