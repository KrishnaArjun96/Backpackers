CREATE VIEW sales_report AS
  SELECT
    `backpackers`.`reservation`.`ResrNo`                                                              AS `Reservation #`,
    month(`backpackers`.`reservation`.`BookingDate`)                                                  AS `Month`,
    year(`backpackers`.`reservation`.`BookingDate`)                                                   AS `Year`,
    (`backpackers`.`reservation`.`BookingFee` + `backpackers`.`reservation`.`Fare`)                   AS `Sale`,
    (SELECT concat(`p`.`FirstName`, ' ', `p`.`LastName`)
     FROM `backpackers`.`person` `p`
       JOIN `backpackers`.`employee` `e`
     WHERE ((`p`.`Id` = `e`.`PersonId`) AND (`backpackers`.`reservation`.`EmployeeSSN` =
                                             `e`.`SSN`)))                                             AS `Representative`
  FROM `backpackers`.`reservation`;
