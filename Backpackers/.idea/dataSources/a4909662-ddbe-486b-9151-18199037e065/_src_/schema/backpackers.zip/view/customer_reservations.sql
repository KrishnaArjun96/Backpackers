CREATE VIEW customer_reservations AS
  SELECT DISTINCT
    (SELECT `backpackers`.`airline`.`Name`
     FROM `backpackers`.`airline`
     WHERE (`backpackers`.`airline`.`Id` = `i`.`AirlineId`))                AS `Airline`,
    concat(`i`.`AirlineId`, ' ', `i`.`FlightNo`)                            AS `Flight`,
    `i`.`ResrNo`                                                            AS `Reservation #`,
    `l`.`LegId`                                                             AS `LegId`,
    `i`.`TravelDate`                                                        AS `TravelDate`,
    `r`.`BookingDate`                                                       AS `Date of Booking`,
    (SELECT DISTINCT concat(`p`.`FirstName`, ' ', `p`.`LastName`)
     FROM `backpackers`.`person` `p`
       JOIN `backpackers`.`customer` `c`
     WHERE ((`c`.`PersonId` = `p`.`Id`) AND (`c`.`UserId` = `r`.`UserId`))) AS `Customer`,
    `rp`.`Name`                                                             AS `Passenger`,
    (SELECT `c`.`Name`
     FROM `backpackers`.`class` `c`
     WHERE (`c`.`Id` = `i`.`ClassId`))                                      AS `Class`,
    `rp`.`MealPref`                                                         AS `MealPref`
  FROM ((((`backpackers`.`booking` `i`
    JOIN `backpackers`.`reservation` `r` ON ((`r`.`ResrNo` = `i`.`ResrNo`))) JOIN `backpackers`.`passenger` `rp`
      ON ((`rp`.`ResrNo` = `i`.`ResrNo`))) JOIN `backpackers`.`flight` `f`
      ON (((`f`.`AirlineId` = `i`.`AirlineId`) AND (`f`.`FlightNo` = `i`.`FlightNo`)))) JOIN `backpackers`.`leg` `l`
      ON (((`i`.`LegId` = `l`.`LegId`) AND (`l`.`AirlineId` = `i`.`AirlineId`) AND (`l`.`FlightNo` = `i`.`FlightNo`))))
  ORDER BY `i`.`ResrNo`, `i`.`LegId`, `rp`.`Name`;
