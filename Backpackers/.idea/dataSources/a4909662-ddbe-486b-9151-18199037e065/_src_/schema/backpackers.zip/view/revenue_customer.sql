CREATE VIEW revenue_customer AS
  SELECT
    (SELECT concat(`backpackers`.`person`.`FirstName`, ' ', `backpackers`.`person`.`LastName`)
     FROM `backpackers`.`person`
     WHERE (`backpackers`.`person`.`Id` = `c`.`PersonId`)) AS `Customer`,
    `c`.`UserId`                                           AS `UserId`,
    sum((`r`.`BookingFee` + `r`.`Fare`))                   AS `Customer Revenue`
  FROM `backpackers`.`customer` `c`
    JOIN `backpackers`.`reservation` `r`
  WHERE (`c`.`PersonId` = `r`.`CustomerId`)
  GROUP BY `r`.`CustomerId`;
