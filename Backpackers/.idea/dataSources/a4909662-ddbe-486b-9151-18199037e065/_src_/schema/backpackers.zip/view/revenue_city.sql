CREATE VIEW revenue_city AS
  SELECT
    `a`.`City`                           AS `City`,
    sum((`r`.`BookingFee` + `r`.`Fare`)) AS `Total revenue`
  FROM `backpackers`.`airport` `a`
    JOIN `backpackers`.`reservation` `r`
    JOIN `backpackers`.`booking` `i`
    JOIN `backpackers`.`leg` `l`
  WHERE ((`r`.`ResrNo` = `i`.`ResrNo`) AND (`i`.`AirlineId` = `l`.`AirlineId`) AND (`i`.`FlightNo` = `l`.`FlightNo`) AND
         (`a`.`Id` = `l`.`Destination`))
  GROUP BY `a`.`City`;
