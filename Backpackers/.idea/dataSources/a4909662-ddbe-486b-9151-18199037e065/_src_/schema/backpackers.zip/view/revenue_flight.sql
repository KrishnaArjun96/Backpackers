CREATE VIEW revenue_flight AS
  SELECT DISTINCT
    concat(`i`.`AirlineId`, ' ', `i`.`FlightNo`)                                        AS `Flight`,
    ((SELECT count(0)
      FROM `backpackers`.`booking` `i`
      WHERE ((`i`.`AirlineId` = `f`.`AirlineId`) AND (`i`.`FlightNo` = `f`.`FlightNo`))
      GROUP BY (`i`.`AirlineId` AND `i`.`FlightNo`)) * (`r`.`BookingFee` + `r`.`Fare`)) AS `Flight Revenue`
  FROM `backpackers`.`flight` `f`
    JOIN `backpackers`.`booking` `i`
    JOIN `backpackers`.`reservation` `r`
  WHERE ((`f`.`FlightNo` = `i`.`FlightNo`) AND (`f`.`AirlineId` = `i`.`AirlineId`) AND (`i`.`ResrNo` = `r`.`ResrNo`));
